using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using Libreria11Mayo;

namespace Libreria11MayoTest;

[TestClass]
public class NumerosBalanceadosTest
{
    [TestMethod]
    [DataRow(1, 9)]
    public void CantidadBalanceados_SeComportaCorrectamente(int l, int esperado) {
        var res = NumerosBalanceados.CantidadBalanceados(l);

        Assert.AreEqual(res, esperado);
    }
}