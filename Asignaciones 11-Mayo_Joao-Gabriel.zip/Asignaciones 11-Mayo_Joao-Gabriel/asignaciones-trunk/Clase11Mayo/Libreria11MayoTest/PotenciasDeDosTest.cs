using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using Libreria11Mayo;

namespace Libreria11MayoTest;

/*
   Para correr estas pruebas, entra a la carpeta de la solución y 
   escribe este comando:

            dotnet test Libreria11MayoTest/Libreria11MayoTest.csproj

 */
[TestClass]
public class PotenciasDeDosTest
{
    [TestMethod]
    [DataRow(0)]
    [DataRow(1)]
    [DataRow(2)]
    public void MultiplosDeDosNoPotencia_DevuelveListaVacia_SinoHayMultiplosEnRango(int n)
    {
        var res = PotenciasDeDos.MultiplosDeDosNoPotencia(n);

        Assert.IsTrue(res.Count == 0, "no hay");
    }

    [TestMethod]
    public void MultiplosDeDosNoPotencia_DevuelveResultadosEsperados_ParaNMenorValido()
    {
        const int menorN = 3;
        var res = PotenciasDeDos.MultiplosDeDosNoPotencia(menorN);

        Assert.AreEqual(res.Single(), 6);
    }

    [TestMethod]
    public void MultiplosDeDosNoPotencia_DevuelveResultadosEsperados_ParaNGrande()
    {
        const int N = 5;
        var res = PotenciasDeDos.MultiplosDeDosNoPotencia(N);

        var esperado = new List<int> { 6, 10, 12, 14, 18, 20, 22, 24, 26, 28, 30 };

        CollectionAssert.AreEqual(res.ToArray(), esperado.ToArray());
    }

    [TestMethod]
    [DataRow("1", 1, 1, true)]
    [DataRow("10", 2, 1, true)]
    [DataRow("10", 1, 0, true)]
    [DataRow("1010", 7, 3, true)]
    [DataRow("1111", 63, 2, true)]
    public void AAndBEsC_ProduceSalidaEsperada(string a, long b, long c, bool resEsperado) {
        var res = PotenciasDeDos.AAndBEsC(a, b, c);

        Assert.AreEqual(res, resEsperado);
    }
    

}