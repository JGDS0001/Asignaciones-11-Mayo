﻿namespace Libreria11Mayo;
public class PotenciasDeDos
{
    private static bool EsPotenciaDeDos(int numero) {
        // De acuerdo al teorema fundamental de la aritmética, todo entero positivo
        // mayor que 1 es un número primo o es un producto de potencias de números
        // primos. Así que podemos "extraer" todos los múltiplos de 2 del número.
        // Si llegamos a la unidad, esto significa que no hubo otro primo en su
        // composición. Ejemplo:
        // 16 (2ˆ4) => 16 / 2 => 8 / 2 => 4 / 2 => 2 / 2 => 1
        // 18 (2 * 3ˆ2) => 18 / 2 => 9. 


        /*while (numero % 2 == 0) {
            numero /= 2;
        }

        return numero == 1;*/

        // reto: hay una manera mucho más eficiente de revisar si un número es una potencia
        // de 2. En su forma binaria, el patrón de bits de  una potencia de dos corresponde
        // a esta nomenclatura:
        //                 1(k ceros)
        // Ejemplo: 16 = 10000
        // Todo número que está a una distancia de 1 para volverse potencia de dos (ejemplo, 15)
        // tiene, en su forma binaria, todos los bits encendidos.
        // Ejemplo: 15 = 1111
        // Fíjate que sucede si hacemos la operación AND sobre los bits de n y n - 1 (n siendo una potencia de dos).
        //    10000b   (16)
        //    01111b   (15)
        //    ======
        //    00000b   (0)
        // Si te animas a cambiar el cuerpo de esta función por otro que implemente esta lógica, deberás saber
        // que el operador binario & es el AND lógico y funciona a nivel de bits. Buena suerte!
        
        return (numero & (numero - 1)) == 0;

    }

    /// Dado un número n (1 <= n <= 12), devuelve una lista con todas
    /// los múltiplos de 2 en el rango [0, 2ˆn] que no son potencias
    /// de 2. Si no existen dichos números para el valor de entrada,
    /// devuelve una lista vacía
    public static IList<int> MultiplosDeDosNoPotencia(int n) {
        // almacenamos los múltiplos de 2 aquí
        var lista = new List<int>();

        int limite = Convert.ToInt32(Math.Pow(2, n));

        // Fíjate que los primeros múltiplos de 2 son: 2, 4 y 6.
        // el único de ellos que no es potencia de 2 es 6. Así
        // que lo mejor es iniciar en 6.

        // Fíjate también que incrementamos de 2 en 2 porque solo estamos interesados
        // en los múltiplos de 2.
        for (int multiploActual = 6; multiploActual <= limite; multiploActual += 2) {
            if (!EsPotenciaDeDos(multiploActual)) {
                lista.Add(multiploActual);
            }
        }

        return lista;
    }

    /// ********** DEBES IMPLEMENTAR ESTA FUNCION *******
    ///
    /// Parámetros: 
    /// a: un numero entero no negativo de 64 bits representado como una
    ///    cadeda de bits de longitud mínima.        
    ///    Ejemplo: "1101" sería el número 13.
    /// b: un numero entero no negativo de 64 bits representado por el tipo
    ///    de datos long
    /// c: un numero entero no negativo de 64 bits representado por el tipo
    ///    de datos long
    ///
    /// La función debe devolver true si alguna permutación de los bits del número
    /// representado por la operación (a AND b) es igual a c. Aquí AND es la operación
    /// binaria AND entre cada par de bits de 'a' y 'b'. Devuelve falso de lo contrario.
    /// Revisa el archivo de pruebas PotenciasDeDosTest.cs para ejemplos de entradas
    /// y salidas válidas.
    /// **************************************************
    public static bool AAndBEsC(string a, long b, long c) 
    {
        /*
             1 - Es claro que un problema fundamental aquí es que los números a y b
                 están representados en tipos distintos, string y long. 

                 Piensa en cómo puedes convertir una representación en otra para 
                 que puedas trabajar más fácilmente.
            
             2 - Una vez tengas los números de a y b en una misma representación,
                 debes pensar en una estrategia para poder aplicar el operador
                 AND a los bits de a y b. 

                 Si la representación que elegiste es la del tipo de datos
                 primitivo long (o sea, que convertiste a `a` en long), entonfces
                 puedes utilizar el operador binario & para hacer esta operación.

             3 - Una vez hayas hecho esa operación, tienes que pensar en cómo 
                 verificar si alguna permutación de los bits del resultado
                 (a AND b) es igual a c.

                 Probar todas las permutaciones es algo tedioso de programar.
                 ¿Puedes hacer uso del total de 1s y 0s para arribar a un resultado?

        */
            long bin = Convert.ToInt64(a, 2) & b;

            return contarUyC(bin, 0) == contarUyC(c, 0) && contarUyC(bin, 1) == contarUyC(c, 1);
    }
        public static int contarUyC(long num, int def)
        {
            int unos = 0;
            int ceros = 0;
            for (int i = 0; i < (sizeof(long)*8); i++)
            {
                if ((num & 1) == 1)
                    unos++;
                
                else
                    ceros++;

                num >>= 1;
            }
            if (def == 1)
                return unos;

            return ceros;

        }

}
