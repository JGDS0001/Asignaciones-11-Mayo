namespace Libreria11Mayo;

public class NumerosBalanceados {
    /*
     ********** DEBES IMPLEMENTAR ESTA FUNCION *******
    Un número entero positivo se considera balanceado si, en su representación decimal, 
    la suma de los dígitos en su primera mitad es igual a la suma de los dígitos en su 
    segunda mitad. Por ejemplo, 4536 es balanceando porque 4+5=3+6. 
    
    Similarmente 44 es balanceado porque 4=4. En el caso de que el número tenga una 
    cantidad impar de dígitos, el dígito del medio no pertenece a ninguna de las mitades. 
    
    Por ejemplo, 85276 es balanceado porque 8+5=7+6. Nota que un número de exactamente un solo dígito
     también se considera balanceado porque cada mitad estaría vacío y, en consecuencia, sus sumas serían 0.

    Dado un numero l, determina la cantidad de números balanceados con exactamente l dígitos.
    */
    public static int CantidadBalanceados(int l) {
        // Sin entender qué nos están pidiendo, no podemos llegar a la solución.
        // ¿Puedes expresar con tus propias palabras cuál es el mandato? Escríbelo
        
        ///Crea una funcion la cual determina cuantos números balanceados existen que tengan una cantidad de dígitos dada. 

        // ¿Entiendes que es l? 

        /// La cantidad de digitos.

        // Imagina que tienes un número de longitud 1. ¿Cómo puedes determinar si es balanceado?

        ///De acuerdo a los tips de arriba, si la cantidad de digitos es impar, el numero del medio no se cuenta
        ///Por lo cual, un numero de longitud uno se considera balanceado, pues esta entre dos nulos que son iguales.

        // Muchas veces ayuda pensar en instancias pequeñas de los problemas. Esto es porque
        // la carga cognitiva es menor para nuestro cerebro. Es más fácil pensar en cosas pequeñas
        // que en cosas grandes. Trata de imaginar 5 monedas en tu cabeza. No es difícil, ¿cierto?
        // Ahora trata de imaginar 1 millón de monedas. Tremendo problemón, ¿no?

        // Entonces responde: ¿cuántos números de tamaño l = 1 son balanceados?

        /// 9 numeros, 1, 2, 3, 4, 5, 6, 7, 8, 9
    
        // ¿Cuántos de 2? ¿Y de 3? ¿Se puede utilizar el resultado de 2 para obtener el de 3?
        
        /// Tambien existen 9 numeros balanceados de 2 digitos, y existen 90 numeros balanceados de 3 digitos. Si es posible obtener el resultado de 3 usando el de 2
        /// Esto se debe a que El resultado del 3 son 10 veces el resultado del 2, pues este tiene 1 digito a mas.

        // ¿Puedes generalizar esto para cualquier tamaño l?

        ///consegui hacer una funcion que me obtiene la cantidad de numeros balanceados dado l. Sin embargo no consigo hacer que funcione para 1, y en mi opinion esta muy mal optimizada.
                   int sup, inf,count=0;
            if (l < 2)
                return 9;
            if(l%2 != 0)
            {
                sup = Convert.ToInt32(Math.Pow(10, l-1));
                inf = Convert.ToInt32(Math.Pow(10, l - 2));
                
            }
            else
            {
                sup = Convert.ToInt32(Math.Pow(10, l ));
                inf = Convert.ToInt32(Math.Pow(10, l - 1));
            }
            for(int i = inf; i<sup;i++)
            {
                if (Balance(i))
                    count++;
            }
            if (l % 2 != 0)
                return count*10;

            return count;


        }
        public static Boolean Balance(int num)
        {
            String Snum = num.ToString();
            String M1 = Snum.Substring(0, Snum.Length / 2);
            String M2 = Snum.Substring((Snum.Length / 2), Snum.Length/2);
            int SumM1=0, SumM2=0;

            for (int i = 0; i < M1.Length; i++)
            {
                SumM1 += int.Parse(M1[i].ToString());
                SumM2 += int.Parse(M2[i].ToString());
            }


            return SumM1 == SumM2;

        }
}
